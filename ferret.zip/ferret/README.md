# Ferreteria Nin
Es un sistema de Inventario y Ventas de proposito ferretero desarrollado con PHP y MySQL.

## Modulos
- Productos
- Categorias
- Caja
- Clientes
- Proveedores
- Inventario
- Usuarios

## Mas informacion
