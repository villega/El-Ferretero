
<?php

//require_once '/core/modules/index/view/processlogin/widget-default.php'; 

// 13 de Abril del 2014
// Module.php
// @brief tareas que se realizan con modulos.

class Module {
	public static function loadLayout(){
		//include "config.inc";
		//global $control;
		
		if(Core::$root==""){
			if(Core::$userr==1)	
				include "core/app/layouts/layout.php";
			else
				include "core/app/layouts/layout2.php";
		echo Core::$userr;
		}else if(Core::$root=="admin/"){
		include "core/app/".Core::$theme."/layouts/layout.php";

		}
		}
		

		
		
	}


		
	







?>
