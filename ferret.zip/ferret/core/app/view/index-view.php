<script>
	window.location='./?view=home';
</script>